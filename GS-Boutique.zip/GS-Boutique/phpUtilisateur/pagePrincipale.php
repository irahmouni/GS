<?php
	require "inc_commun.php";
	require "header_et_menu.php";
?>

<CENTER>
<br><br>
<h1>Stock</h1>
<a class="menu" href="visualiserStock.php">Consulter le stock </a><br>
<a class="menu" href="editerStock.php">Modifier le contenu du stock</a><br>
<a class="menu" href="changerStockAGerer.php">Changer le stock à gérer</a><br>
<br>


</CENTER>
<?php
	require "footer.php";
?>