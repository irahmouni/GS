</td>
<td class="tdDroiteStock" align="center" valign="top">
	<br>
	<br><br><br>
	Etat du stock<br><br>
	<table width="700px" class="tableStockADroite">
	<tr><th>Nom</th><th>Prix<br>TTC</th><th>Quantite<br>réelle</th></tr>
	<?php
		foreach ($stock->tLigneStock as $ligneStock) {
			$article=$ligneStock->article;
			$quantiteReelle=$ligneStock->quantiteReelle;
			$quantiteVirtuelle=$ligneStock->quantiteVirtuelle;
			if ($quantiteReelle==$quantiteVirtuelle) $quantiteVirtuelle="";
			$quantiteReelle=afficherEntierSansDec($quantiteReelle);
			$quantiteVirtuelle=afficherEntierSansDec($quantiteVirtuelle);
			if ($quantiteReelle>=0) {
				$styleQuantiteReelle="tdQuantite";
			} else {
				$styleQuantiteReelle="tdQuantiteNegative";
			};
			
			echo "<tr><td>$article->nom</td><td class=\"tdPrix\">$article->prixTTCCourant</td><td class=\"$styleQuantiteReelle\">$quantiteReelle</td></tr>";
		}
	?>
	</table>
</td>
</tr>
</table>
</body>
</html>


<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">

    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">

</head>
<body>
 


    <!-- end navbar -->


<div class="container1">
    <div class="row">
        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img1" src="../img/Baskette/adidas_predator.jpg">
            <h5>Adidas Predator Mania</h5>
           
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img2" src="../img/Baskette/adidas_pure.jpg">
            <h5>Adidas Ace PureControl</h5>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img3" src="../img/Baskette/adidas_purechaos.jpg">
            <h5>Adidas X16 Purechaos</h5>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img4" src="../img/Baskette/nike_hyperv.jpg">
            <h5>Nike Hypervenom Phantom III</h5>
        </article>


        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img5" src="../img/Baskette/nike_tiempo.jpg">
            <h5>Nike Tiempo Ligeria</h5>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img6" src="../img/Baskette/nike_mercu.jpg">
            <h5>Nike Mercurial Superfly</h5>
        </article>

	</div>
	<div class="container2">
    <div class="row">
        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img9" src="../img/Livre/Livre-gabarit_slide_smarphone_pel_2020.jpg">
            <h5>Gabarit slide smarphone pel</h5>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img10" src="../img/Livre/Livre-La biche au bois dormant.jpg">
            <h5>La biche au bois dormant</h5>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img11" src="../img/Livre/Vege.jpg">
            <h5>Le monde végital et nous</h5>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img12" src="../img/Livre/Livre-Le Tourne Page.png">
            <h5>NLe Tourne Page</h5>
        </article>


        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img13" src="../img/Livre/Livre-plantes_grimpantes.jpg">
            <h5>Plantes grimpantes</h5>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img14" src="../img/Livre/boussoul.jpg">
            <h5>Un monde sans BOUSSOLE</h5>
        </article>

	</div>
	<div class="container3">
    <div class="row">

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
			<img id="img15" src="../img/Parfum/B.jpg">           
            <h5>BLEU DE CHANEL</h5>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img16" src="../img/Parfum/Parfum-coco-mademoiselle-chanel.jpg">
            <h5>Coco mademoiselle chanel</h5>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img17" src="../img/Parfum/Parfum-giorgio-armani-acqua-di-gioia-.jpg">
            <h5>Giorgio armani acqua di gioia</h5>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img18" src="../img/Parfum/Bs.jpg">
            <h5>LA BELLE</h5>
        </article>


        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img19" src="../img/Parfum/Parfum-paco-rabanne-pure-xs-for-her-.jpg">
            <h5>Paco rabanne pure xs for her</h5>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img20" src="../img/Parfum/Parfum-scandal.jpg">
            <h5>Scandal</h5>
        </article>

    </div>


</br>
</div>
</body>
</html>


