<?php
	require "inc_commun.php";
	require "header_et_menu.php";
?>

<CENTER>
<br><br><br><br>
<a class="menu" href="gererStocks.php">Gérer les stocks</a><br>
<br><br>
<a class="menu" href="gererUtilisateurs.php">Gérer les utilisateurs</a><br>
</CENTER>
<?php
	require "footer.php";
?>