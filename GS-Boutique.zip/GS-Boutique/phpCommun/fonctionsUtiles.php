<?php

	function afficherEntierSansDec($nombre) {
		if (is_null($nombre) || trim($nombre)=="") {
			$nRet="";
		} else {
			$nRet=floatval($nombre);
		}
		return $nRet;
	}
	
	