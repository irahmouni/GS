<!DOCTYPE html>
<html>
<HEAD>
<TITLE>GS-Boutique</TITLE>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="imagetoolbar" content="no">
<META name="keywords" content="gestion,stock">
<LINK media="screen" href="../phpCommun/style.css" type="text/css" rel="stylesheet">
<link rel="icon" type="image/x-icon" href="../img/GS.jpg" />
</HEAD>
<BODY>
