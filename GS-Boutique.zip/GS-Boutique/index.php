<?php 
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>GS-Boutique</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">

</head>
<body>

   


    <!-- end navbar -->

<br>
<div class="container-fluid bandeau">
    <div class="row">
        <h1 class="col-8">GS-Boutique</h1>
        <div class="col-2">
            <p id="article">panier vide</p>
        </div>
        
        <div class="col-2">
            <img  id=panier src="img/panier.jpg">
        </div>

    </div>
    <div> 
    
        <a href="phpCommun/login.php" class="btn btn-success" >Login</a>
    </div>
</div>


<div class="container1">
    <div class="row">
        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img1" src="img/Baskette/adidas_predator.jpg">
            <h5>Adidas Predator Mania</h5>
            <button id="0" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>155.25€ TTC</p>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img2" src="img/Baskette/adidas_pure.jpg">
            <h5>Adidas Ace PureControl</h5>
            <button id="1" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>175.25€ TTC</p>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img3" src="img/Baskette/adidas_purechaos.jpg">
            <h5>Adidas X16 Purechaos</h5>
            <button id="2" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>125.25€ TTC</p>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img4" src="img/Baskette/nike_hyperv.jpg">
            <h5>Nike Hypervenom Phantom III</h5>
            <button id="3" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>145.25€ TTC</p>
        </article>


        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img5" src="img/Baskette/nike_tiempo.jpg">
            <h5>Nike Tiempo Ligeria</h5>
            <button id="4" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>165.25€ TTC</p>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img6" src="img/Baskette/nike_mercu.jpg">
            <h5>Nike Mercurial Superfly</h5>
            <button id="5" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>105.25€ TTC</p>
        </article>

	</div>
	<div class="container2">
    <div class="row">
        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img9" src="img/Livre/Livre-gabarit_slide_smarphone_pel_2020.jpg">
            <h5>Gabarit slide smarphone pel</h5>
            <button id="0" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>3.99€ TTC</p>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img10" src="img/Livre/Livre-La biche au bois dormant.jpg">
            <h5>La biche au bois dormant</h5>
            <button id="1" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>5.99€ TTC</p>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img11" src="img/Livre/Vege.jpg">
            <h5>Le monde végital et nous</h5>
            <button id="2" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>7.33€ TTC</p>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img12" src="img/Livre/Livre-Le Tourne Page.png">
            <h5>NLe Tourne Page</h5>
            <button id="3" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>7.17€ TTC</p>
        </article>


        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img13" src="img/Livre/Livre-plantes_grimpantes.jpg">
            <h5>Plantes grimpantes</h5>
            <button id="4" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>9.99€ TTC</p>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img14" src="img/Livre/boussoul.jpg">
            <h5>Un monde sans BOUSSOLE</h5>
            <button id="5" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>12.60€ TTC</p>
        </article>

	</div>
	<div class="container3">
    <div class="row">

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
			<img id="img15" src="img/Parfum/B.jpg">
           
            <h5>BLEU DE CHANEL</h5>
            <button id="0" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>83.33€ TTC</p>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img16" src="img/Parfum/Parfum-coco-mademoiselle-chanel.jpg">
            <h5>Coco mademoiselle chanel</h5>
            <button id="1" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>155.55€ TTC</p>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img17" src="img/Parfum/Parfum-giorgio-armani-acqua-di-gioia-.jpg">
            <h5>Giorgio armani acqua di gioia</h5>
            <button id="2" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>40.99€ TTC</p>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img18" src="img/Parfum/Bs.jpg">
            <h5>LA BELLE</h5>
            <button id="3" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>47.33€ TTC</p>
        </article>


        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img19" src="img/Parfum/Parfum-paco-rabanne-pure-xs-for-her-.jpg">
            <h5>Paco rabanne pure xs for her</h5>
            <button id="4" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>75.30€ TTC</p>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <img id="img20" src="img/Parfum/Parfum-scandal.jpg">
            <h5>Scandal</h5>
            <button id="5" class="btn btn-success" onclick="achat(this), total()">Ajouter au panier</button>
            <p>55.75€ TTC</p>
        </article>

    </div>


</br>
</br>

    <div class="row">
        <div class="col-12">
            <h5 id="tot" >Total du panier : 0€ </h5>
        </div>
        </br>
        <div class="col-12">
            <h8 id="tva" ></h8>
        </div>
    </div>
    </br>
    <table class="table">
        <thead>
        <tr>
            <th>Produit</th>
            <th>Quantité</th>
            <th>P.U</th>
            <th>Total</th>
        </tr>

        </thead>
        <tbody>
        </tbody>
    </table>





</div>
<script src="js/jquery.js"></script>
<script type="text/javascript" src="js/script.js"></script>
</body>
</html>





